# **2D Platformer Parkour Game Development Opdracht: "Squirrel's Forest Adventure"**

---

## **Introductie**

---

In deze opdracht gaan we een 2D platformer ontwikkelen in de stijl van klassieke Mario-spellen. De game wordt gebouwd in Unity en bevat retro 8-bit graphics. De speler bestuurt een speelse eekhoorn die parkour-bewegingen moet gebruiken om door een bosrijke omgeving te navigeren. Het doel is om de eekhoorn te helpen voedsel te verzamelen en veilig door verschillende uitdagende levels te komen. Dit project richt zich op het combineren van parkour-mechanismen met een natuurlijke bosomgeving waarin het dier zich thuis voelt.

## **Gameplay Kenmerken**

---

### **Kernfuncties**

1. **Eekhoorn Parkour Bewegingen**
    - De speler bestuurt een lenige eekhoorn die kan springen, rennen, klimmen en van boom naar boom kan glijden. Deze vloeiende parkourbewegingen vormen de kern van het spel en moeten intuïtief aanvoelen.
2. **Obstakels en Uitdagingen in het Bos**
    - Het bos zit vol obstakels zoals diepe ravijnen, vijvers, rotsen en bewegende takken. De eekhoorn moet zijn parkourvaardigheden gebruiken om veilig door deze obstakels heen te navigeren.
3. **Leefomgeving: Het Bos**
    - Het spel speelt zich af in een levendig, met pixel art vormgegeven bos. Boomtoppen, takken en bladerdek vormen platformen waar de eekhoorn op kan springen en langs kan klimmen. Dit natuurlijke thema biedt variatie in leveldesign, van open boomtoppen tot donkere bospaden.
4. **Verzamelobjecten: Eikels**
    - De speler moet eikels verzamelen die verspreid zijn over de levels. Deze verzamelobjecten verhogen de score en kunnen soms ook toegang geven tot verborgen delen van het level.
5. **Pixel Art Stijl (8-bit)**
    - De game gebruikt een klassieke 8-bit pixel art stijl, met kleurrijke graphics die de natuurlijke omgeving van het bos tot leven brengen.
6. **Power-ups**
    - Voeg power-ups toe zoals "Super Springveren", waarmee de eekhoorn hoger kan springen, of "Turbo Tails" voor extra snelheid. Deze power-ups bieden tijdelijke boosts die nodig zijn om bepaalde delen van de levels te voltooien.

### **Geavanceerde Functies**

1. **Geavanceerde Parkour Mechanismen**
    - Breid de parkourvaardigheden van de eekhoorn uit met geavanceerde bewegingen zoals muurklimmen, dubbele sprongen en glijden langs takken. Dit geeft meer uitdaging en dynamiek aan de gameplay.
2. **Verschillende Weersomstandigheden**
    - Ontwikkel meerdere levels met variërende weersomstandigheden, zoals regen die platforms glad maakt, of wind die de sprongen van de eekhoorn beïnvloedt. Dit zorgt voor extra variatie en uitdaging.

## **Technische Overwegingen**

---

1. **Gebruik van Specifieke Technologieën of Tools**
    - Unity is de voorgeschreven game engine voor deze opdracht, met C# als programmeertaal. Voor het maken van de 8-bit pixel art kunnen tools zoals Aseprite of Piskel gebruikt worden.
2. **Optimalisatie en Performance**
    - Zorg voor een efficiënte implementatie van de physics en sprite rendering, zodat het spel soepel draait op verschillende platformen. Houd het aantal objecten op het scherm beheersbaar en optimaliseer de art assets om overbelasting te voorkomen.
3. **Platform Compatibiliteit**
    - De game moet compatibel zijn met PC (Windows en Mac) en eventueel via WebGL in een browser kunnen draaien. Test de controls op zowel toetsenbord als gamepad om te zorgen voor optimale gebruikerservaring.

## **Leveringsvereisten**

---

1. **Documentatie**
    - Voeg een ontwerpdocument toe waarin het concept van het spel, het gedrag van de eekhoorn en de leveldesigns worden beschreven. Zorg ook voor een handleiding waarin de controls en power-ups worden uitgelegd.
2. **Testing**
    - Test het spel uitgebreid op bugs, prestaties en gebruikerservaring. Test verschillende levels en parkourmechanismen om te zorgen dat ze goed functioneren. Documenteer eventuele bugs en hun oplossingen in een testverslag.
3. **Demonstratie en Presentatie**
    - Presenteer het spel door de belangrijkste gameplay-elementen te tonen, zoals de parkourbewegingen van de eekhoorn en de uitdagende bosomgevingen. Leg uit hoe de levels zijn ontworpen en hoe de power-ups de speler helpen.

## **Conclusie**

---

Deze opdracht biedt studenten de kans om een retro-geïnspireerde 2D platformer te ontwikkelen, waarin een speelse eekhoorn centraal staat. Door het ontwerpen van parkourmechanismen en het creëren van een natuurlijke bosomgeving, leren studenten zowel technische vaardigheden in Unity als creatief levelontwerp. De uitdaging ligt in het combineren van soepele bewegingen, aantrekkelijke pixel art en boeiende gameplay die spelers uitnodigt om de wereld te verkennen en te navigeren.