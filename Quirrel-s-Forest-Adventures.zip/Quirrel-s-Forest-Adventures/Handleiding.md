# **Handleiding voor Quirrel's Forest Adventure**

## **Introductie**
Welkom bij *Quirrel's Forest Adventure*! In dit spannende 2D-platformspel bestuur je een eekhoorn die onderweg is naar zijn huisje. Verzamel zoveel mogelijk eikels om je score te verhogen en ontwijk vijanden die je proberen tegen te houden. Het doel is om zo snel mogelijk de finish te bereiken en een hoge score te behalen!

---

## **Spelregels**
- **Doel van het spel:**  
  Bereik de finish zo snel mogelijk terwijl je onderweg zoveel mogelijk eikels verzamelt.
- **Score verhogen:**  
  Elke opgepakte eikel geeft punten. Hoe meer eikels je verzamelt, hoe hoger je score.
- **Pas op voor vijanden:**  
  - Sprinkhanen en mieren proberen je te stoppen. Raak ze niet, want dan verlies je direct!

---

## **Besturing**
- **Lopen:**  
  - **Linkerpijltoets (←):** Beweeg naar links.  
  - **Rechterpijltoets (→):** Beweeg naar rechts.  
- **Springen:**  
  - **Pijl omhoog (↑):** Spring om obstakels te ontwijken of hoger gelegen platformen te bereiken.

---

## **Tips voor succes**
1. **Blijf bewegen:**  
   Probeer niet te lang stil te staan, want je tijd telt mee voor je eindscore!
2. **Let op vijanden:**  
   Observeer de bewegingen van sprinkhanen en mieren. Wacht op het juiste moment om ze te ontwijken.
3. **Plan je sprongen:**  
   Spring op het juiste moment om moeilijk bereikbare eikels te pakken en obstakels te vermijden.
4. **Power-ups:**  
   Kijk uit naar speciale krachten in het spel die je tijdelijk onoverwinnelijk maken of sneller laten bewegen.

---

## **Puntentelling**
- **Eikels verzamelen:**  
  - Elke opgepakte eikel geeft **10 punten**.
- **Tijdscore:**  
  - Hoe sneller je de finish bereikt, hoe hoger je bonuspunten voor tijd.

---

## **Minimale systeemvereisten**
- **Platform:** Windows of macOS  
- **Processor:** Dual-Core 2.0 GHz  
- **Geheugen:** 4 GB RAM  
- **Opslagruimte:** 500 MB vrije ruimte  
- **Software:** Unity Player vereist (meegeleverd met het spel).

---

## **Installatie-instructies**
1. Download het spelbestand via de bijgeleverde link.
2. Pak het bestand uit (indien gezipt) en dubbelklik op het `.exe`-bestand (voor Windows) of `.app`-bestand (voor macOS).
3. Volg de installatie-instructies op het scherm.
4. Start het spel en begin je avontuur!

---

## **Veel plezier!**
We hopen dat je geniet van *Quirrel's Forest Adventure*! Veel succes met het verzamelen van eikels en het ontwijken van vijanden. Laat zien dat jij de snelste en slimste eekhoorn bent in het bos! 🌳🐿️
